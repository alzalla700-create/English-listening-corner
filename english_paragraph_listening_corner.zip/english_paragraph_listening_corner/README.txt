ENGLISH PARAGRAPH LISTENING CORNER

This package contains index.html, a single mobile-friendly webpage with all five paragraphs and separate Listen / Pause / Stop controls.

HOW TO USE IT:
1. Open index.html in a modern browser to test it.
2. The page uses the browser's built-in text-to-speech feature. It requests an American English (en-US) voice, but the exact voice depends on the student's phone/browser and installed voices.
3. To let students open it by scanning one QR code, the page must be published at a public web address first. A QR code cannot reliably open a local file on your computer for every student.
4. After publishing, create a QR code that points to the public webpage address.

PARAGRAPHS INCLUDED:
- A Day in Egypt
- Ras Mohamed National Park
- Life in the Village
- A Day at Your School
- Khan El Khalili
